// Cloudflare Worker: read-only relay between the iPad page and your Notion database.
// Secrets: NOTION_TOKEN, PASSCODE.  Variables: ALLOWED_ORIGIN (your GitHub Pages origin), optional DATA_SOURCE_ID, DATABASE_ID.

const DEFAULT_DATA_SOURCE_ID = '14e22bf7-29e6-81df-923e-000bd1370477';
const DEFAULT_DATABASE_ID = '14e22bf7-29e6-8118-accd-e33efc23734c';

const text = (p) => (p && (p.rich_text || p.title) ? (p.rich_text || p.title).map((t) => t.plain_text).join('') : '');
const sel = (p) => (p && p.select ? p.select.name : '');

function mapPage(pg) {
  const p = pg.properties || {};
  return {
    id: pg.id,
    url: pg.url,
    code: text(p['Episode Code']),
    title: text(p['Name']),
    series: sel(p['Series']),
    status: sel(p['Status']),
    description: text(p['Description']),
    keyConcepts: text(p['Key Concepts']),
    scriptPrompt: text(p['Script Prompt']),
    publishedDate: p['Published Date'] && p['Published Date'].date ? p['Published Date'].date.start : null,
  };
}

async function queryAll(env) {
  const token = env.NOTION_TOKEN;
  const body = (cursor) => JSON.stringify({
    page_size: 100,
    ...(cursor ? { start_cursor: cursor } : {}),
    filter: { property: 'Status', select: { does_not_equal: 'Published' } },
  });
  const attempts = [
    { url: `https://api.notion.com/v1/data_sources/${env.DATA_SOURCE_ID || DEFAULT_DATA_SOURCE_ID}/query`, version: '2025-09-03' },
    { url: `https://api.notion.com/v1/databases/${env.DATABASE_ID || DEFAULT_DATABASE_ID}/query`, version: '2022-06-28' },
  ];
  let lastError = 'Unknown error';
  for (const a of attempts) {
    const rows = [];
    let cursor = null;
    let ok = true;
    do {
      const res = await fetch(a.url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Notion-Version': a.version, 'Content-Type': 'application/json' },
        body: body(cursor),
      });
      const json = await res.json();
      if (!res.ok) { lastError = `${res.status} ${json.message || ''}`.trim(); ok = false; break; }
      rows.push(...json.results.map(mapPage));
      cursor = json.has_more ? json.next_cursor : null;
    } while (cursor);
    if (ok) return rows;
  }
  throw new Error(lastError);
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = env.ALLOWED_ORIGIN || '*';
    const cors = {
      'Access-Control-Allow-Origin': allowed === '*' ? '*' : allowed,
      'Access-Control-Allow-Headers': 'X-Passcode, Content-Type',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Vary': 'Origin',
    };
    const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...cors, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (allowed !== '*' && origin && origin !== allowed) return json({ error: 'Origin not allowed' }, 403);
    if (!env.PASSCODE || request.headers.get('X-Passcode') !== env.PASSCODE) return json({ error: 'Wrong passcode' }, 401);

    const { pathname } = new URL(request.url);
    if (pathname === '/ping') return json({ ok: true });
    if (pathname === '/episodes') {
      try {
        const rows = await queryAll(env);
        return json({ episodes: rows, fetchedAt: new Date().toISOString() });
      } catch (e) {
        return json({ error: 'Notion request failed: ' + e.message }, 502);
      }
    }
    return json({ error: 'Not found' }, 404);
  },
};
